// JavaScript Document 
jQuery(document).ready(function($) {
      if($('.preloader-center')){
          $('.preloader-center').hide();
      }
});
    
