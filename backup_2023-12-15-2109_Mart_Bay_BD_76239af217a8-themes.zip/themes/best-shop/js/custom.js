jQuery(document).ready(function ($) {
    //search modal
    $('.header-search > button').on('click', function () {
        $('.header-search-form').fadeIn();
        $('.search-field').focus();
    });
    $('.header-search .close').on('click', function () {
        $('.header-search-form').fadeOut();
    });

    $('.search-form').on('click', function (e) {
        e.stopPropagation();
    });

    $('.header-search-form').on('click', function () {
        $('.header-search-form').fadeOut();
    });

    //mobile-menu
    $('<button class="angle-down"> </button>').insertAfter( $(".main-navigation.mobile-navigation ul .menu-item-has-children > a"));
    $('.main-navigation.mobile-navigation ul li .angle-down').on('click', function () {
        $(this).next().slideToggle();
        $(this).toggleClass('active');
    });

    var adminBar = document.querySelector('#wpadminbar');
    if (adminBar !== null) {
        var adminHeight = adminBar.offsetHeight;
        var mobHeaderTop = document.querySelector('.header-bottom-slide-inner');
        // mobHeaderTop.style.top = adminHeight + 'px';
    }

    //mobileheaderwhenadminbarpresent
    function styleOne() {
        if (document.querySelector('.site-header.style-one') !== null) {
            var StyleOne = document.querySelector('.site-header.style-one');
            StyleOne.style.top = adminHeight + 'px';
        }
    }
    
    window.addEventListener('resize', function () {
        styleOne();
    });

    window.addEventListener('load', function () {
        styleOne();
    });

    //accessibility
    $('.menu li a, .menu li').on('focus', function() {
        $(this).parents('li').addClass('focus');
    }).blur(function() {
        $(this).parents('li').removeClass('focus');
    });

    $("#menu-opener").on('click', function () {
        $("body").addClass("menu-open");
        $(".mobile-menu-wrapper .primary-menu-list").addClass("toggled");
    });
  
    $(".mobile-menu-wrapper .close-main-nav-toggle ").on('click', function () {
    $("body").removeClass("menu-open");
    $(".mobile-menu-wrapper .primary-menu-list").removeClass("toggled");
    });

        
    
    $('.marquee.aft-flash-slide').marquee({
        //duration in milliseconds of the marquee
        speed: 80000,
        //gap in pixels between the tickers
        gap: 0,
        //time in milliseconds before the marquee will start animating
        delayBeforeStart: 0,
        //'left' or 'right'
        // direction: 'right',
        //true or false - should the marquee be duplicated to show an effect of continues flow
        duplicated: true,
        pauseOnHover: true,
        startVisible: true
    });     

});

//Tabs js
function rudrSwitchTab(rudr_tab_id, rudr_tab_content, rudr_tab_class) {
	// first of all we get all tab content blocks (I think the best way to get them by class names)
	var x = document.getElementsByClassName(rudr_tab_class);
	var i;
	for (i = 0; i < x.length; i++) {
		x[i].style.display = 'none'; // hide all tab content
	}
	document.getElementById(rudr_tab_content).style.display = 'block'; // display the content of the tab we need
 
	// now we get all tab menu items by class names (use the next code only if you need to highlight current tab)
	x = document.getElementsByClassName("tabmenu");
    
	for (i = 0; i < x.length; i++) {
		x[i].className = 'tabmenu'; 
	}
	document.getElementById(rudr_tab_id).className = 'tabmenu active';
}


/*!
* Countdown v0.1.0
* https://github.com/fengyuanchen/countdown
*
* Copyright 2014 Fengyuan Chen
* Released under the MIT license
*/

! function(a) {
    "function" == typeof define && define.amd ? define(["jquery"], a) : a(jQuery)
}(function(a) {
    "use strict";
    var b = function(c, d) {
        this.$element = a(c), this.defaults = a.extend({}, b.defaults, this.$element.data(), a.isPlainObject(d) ? d : {}), this.init()
    };
    b.prototype = {
        constructor: b,
        init: function() {
            var a = this.$element.html(),
                b = new Date(this.defaults.date || a);
            b.getTime() && (this.content = a, this.date = b, this.find(), this.defaults.autoStart && this.start())
        },
        find: function() {
            var a = this.$element;
            this.$days = a.find("[data-days]"), this.$hours = a.find("[data-hours]"), this.$minutes = a.find("[data-minutes]"), this.$seconds = a.find("[data-seconds]"), this.$days.length + this.$hours.length + this.$minutes.length + this.$seconds.length > 0 && (this.found = !0)
        },
        reset: function() {
            this.found ? (this.output("days"), this.output("hours"), this.output("minutes"), this.output("seconds")) : this.output()
        },
        ready: function() {
            var a, b = this.date,
                c = 100,
                d = 1e3,
                e = 6e4,
                f = 36e5,
                g = 864e5,
                h = {};
            return b ? (a = b.getTime() - (new Date).getTime(), 0 >= a ? (this.end(), !1) : (h.days = a, h.hours = h.days % g, h.minutes = h.hours % f, h.seconds = h.minutes % e, h.milliseconds = h.seconds % d, this.days = Math.floor(h.days / g), this.hours = Math.floor(h.hours / f), this.minutes = Math.floor(h.minutes / e), this.seconds = Math.floor(h.seconds / d), this.deciseconds = Math.floor(h.milliseconds / c), !0)) : !1
        },
        start: function() {
            !this.active && this.ready() && (this.active = !0, this.reset(), this.autoUpdate = this.defaults.fast ? setInterval(a.proxy(this.fastUpdate, this), 100) : setInterval(a.proxy(this.update, this), 1e3))
        },
        stop: function() {
            this.active && (this.active = !1, clearInterval(this.autoUpdate))
        },
        end: function() {
            this.date && (this.stop(), this.days = 0, this.hours = 0, this.minutes = 0, this.seconds = 0, this.deciseconds = 0, this.reset(), this.defaults.end())
        },
        destroy: function() {
            this.date && (this.stop(), this.$days = null, this.$hours = null, this.$minutes = null, this.$seconds = null, this.$element.empty().html(this.content), this.$element.removeData("countdown"))
        },
        fastUpdate: function() {
            --this.deciseconds >= 0 ? this.output("deciseconds") : (this.deciseconds = 9, this.update())
        },
        update: function() {
            --this.seconds >= 0 ? this.output("seconds") : (this.seconds = 59, --this.minutes >= 0 ? this.output("minutes") : (this.minutes = 59, --this.hours >= 0 ? this.output("hours") : (this.hours = 23, --this.days >= 0 ? this.output("days") : this.end())))
        },
        output: function(a) {
            if (!this.found) return void this.$element.empty().html(this.template());
            switch (a) {
                case "deciseconds":
                    this.$seconds.text(this.getSecondsText());
                    break;
                case "seconds":
                    this.$seconds.text(this.seconds);
                    break;
                case "minutes":
                    this.$minutes.text(this.minutes);
                    break;
                case "hours":
                    this.$hours.text(this.hours);
                    break;
                case "days":
                    this.$days.text(this.days)
            }
        },
        template: function() {
            return this.defaults.text.replace("%s", this.days).replace("%s", this.hours).replace("%s", this.minutes).replace("%s", this.getSecondsText())
        },
        getSecondsText: function() {
            return this.active && this.defaults.fast ? this.seconds + "." + this.deciseconds : this.seconds
        }
    }, b.defaults = {
        autoStart: !0,
        date: null,
        fast: !1,
        end: a.noop,
        text: "%s days, %s hours, %s minutes, %s seconds"
    }, b.setDefaults = function(c) {
        a.extend(b.defaults, c)
    }, a.fn.countdown = function(c) {
        return this.each(function() {
            var d = a(this),
                e = d.data("countdown");
            e || d.data("countdown", e = new b(this, c)), "string" == typeof c && a.isFunction(e[c]) && e[c]()
        })
    }, a.fn.countdown.constructor = b, a.fn.countdown.setDefaults = b.setDefaults, a(function() {
        a("[countdown]").countdown()
    })
});



